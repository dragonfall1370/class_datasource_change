/*
with JPInfo as (select JP.jobPostingID as JobID, JP.title as JobTitle
, Cl.clientID as ContactID, Cl.userID as ClientUserID
, UC.name as ContactName, UC.email as ContactEmail
, CC.clientCorporationID as CompanyID, CC.name as CompanyName
from bullhorn1.BH_JobPosting JP
left join bullhorn1.BH_Client Cl on JP.clientUserID = Cl.userID
left join bullhorn1.BH_UserContact UC on JP.clientUserID = UC.userID
left join bullhorn1.BH_ClientCorporation CC on JP.clientCorporationID = CC.clientCorporationID
where 1=1
and Cl.isPrimaryOwner = 1)

--Search information in JPInfo table:
--select * from JPInfo order by JobID

, CandidateInfo as (select CA.userID as CandidateUserID, CA.candidateID
, UC.userID, UC.name as CandidateName, UC.email as CandidateEmail
from bullhorn1.BH_Candidate CA
left join bullhorn1.BH_UserContact UC on CA.userID = UC.userID
where CA.isPrimaryOwner = 1)

/* Search information in CandidateInfo table
select * from CandidateInfo
order by CandidateUserID
*/
*/
 select top 10000
-- select
	 J.JobNumber as 'application-positionExternalId'
	,J.Contactid as 'application-candidateExternalId'
	,J.ClientId as 'Contact External ID'
	--,I.CandidateId as 'Interviews - CandidateId'
	--,P.ContactId as 'Placements - ContactId'
	
	,J.Position as 'Job Title'
	,J.ClientName as 'Contact Name'
	,J.Company as 'Company Name'
	,J.CompanyId as 'Company External ID'

	--,O.ShortlistId as 'Offers - ShortlistId'
	--, as 'application-stage' --This field only accepts: SHORTLISTED,SENT,1ST_INTERVIEW,2ND_INTERVIEW,OFFERED,PLACED, INVOICED, Other values will not be recognized.
	, case 
		when J.Interested = 'true' then 'SHORTLISTED' 
		when J.NotInterested = 'true' then 'SHORTLISTED' 
		when J.CVReceived = 'true' then 'SHORTLISTED' 
		when J.CVRevised = 'true' then 'SHORTLISTED' 
		when J.Withdrawn = 'true' then 'SHORTLISTED' 
		when J.Rejected = 'true' then 'SHORTLISTED' 
		when J.CVSent = 'true' then 'SENT'
		when J.Interview1 is not null then '1ST_INTERVIEW'
		when J.ToBeArranged = 'true' then '1ST_INTERVIEW'
		when J.Accepted = 'true' then 'OFFERED'
		when J.Offered = 'true' then 'OFFERED' 
		when J.RejectedOffer = 'true' then 'OFFERED'
	end as 'application-stage'

-- select top 100 *
-- select count(*)
from CandidatesList2 J
--left join Offers O on J.Contactid = O.CandidateId
--left join Interviews I on J.JobNumber = I.VacancyId
--left join Placements P on J.JobNumber = P.VacancyId
where J.ContactId != '' and J.ContactId is not null
--and J.ContactId = '100035-2653-1039' and J.JobNumber = '883176-8278-8254'
order by J.ContactId

/*
-- select count(*) --357155
-- 
select
-- select distinct J.Interview1
	 J.JobNumber as 'application-positionExternalId'
	,J.Contactid as 'application-candidateExternalId'
	,J.ClientId as 'Contact External ID'
	, case 
		when J.Accepted = 'true' then 'OFFERED'
		when J.RejectedOffer = 'true' then 'OFFERED'
		when J.Offered = 'true' then 'OFFERED' 
		when I.InterviewNo > 1 then '2ND_INTERVIEW'
		when J.Interview1 is not null then '1ST_INTERVIEW'
		when J.ToBeArranged = 'true' then '1ST_INTERVIEW'
		when J.CVSent = 'true' then 'SENT'
		when J.Interested = 'true' then 'SHORTLISTED' 
		when J.NotInterested = 'true' then 'SHORTLISTED' 
		when J.CVReceived = 'true' then 'SHORTLISTED' 
		when J.CVRevised = 'true' then 'SHORTLISTED' 
		when J.Withdrawn = 'true' then 'SHORTLISTED' 
		when J.Rejected = 'true' then 'SHORTLISTED' 
	end as 'application-stage'
from CandidatesList2 J
--left join Offers O on J.Contactid = O.CandidateId -- 357313 
-- select top 20 * from Offers where CandidateId = '489156-2390-15121'
-- select O.CandidateId from Offers O group by O.CandidateId having count(*) > 1

left join Interviews I on J.Contactid = I.CandidateId -- 455180
-- select top 20 * from Interviews where CandidateId = '489156-2390-15121' and VacancyId = '829813-2813-15147' order by CandidateId 
-- select I.CandidateId from Interviews I group by I.CandidateId having count(*) > 1
-- select distinct InterviewNo from Interviews I
-- select * from Interviews where InterviewNo > 1 order by CandidateId
-- select * from Interviews where InterviewNo > 10 order by CandidateId

left join Placements P on J.Contactid = P.Contactid -- 456091
-- select top 20 * from Placements

where J.ContactId != '' and J.ContactId is not null
and J.ContactId = '482468-3735-13189' -- '489156-2390-15121' --and J.JobNumber = '883176-8278-8254'

order by J.ContactId

*/