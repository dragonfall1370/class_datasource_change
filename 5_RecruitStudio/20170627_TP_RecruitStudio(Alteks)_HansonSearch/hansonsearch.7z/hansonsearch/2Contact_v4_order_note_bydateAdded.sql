/*
with tmp_1(userID, email) as 
(select userID, REPLACE(ISNULL(email,'') + ',' + ISNULL(email2,'') + ',' + ISNULL(email3,''), ',,', ',') as email
from bullhorn1.BH_UserContact
 )
 --select * from tmp_1
 --select userID, email, CHARINDEX(email,',',0) from tmp_1
 , tmp_2(userID, email) as (
select userID, CASE WHEN CHARINDEX(',',email,1) = 1 THEN RIGHT(email, len(email)-1)
	ELSE email END as email
from tmp_1
)
 , tmp_3(userID, email) as (
select userID, CASE WHEN CHARINDEX(',',email,len(email)) = len(email) 
	THEN LEFT(email, CASE WHEN len(email) < 1 THEN 0 ELSE len(email) - 1 END)
	ELSE email END as email
from tmp_2
)

, tmp_4(userID, Notes) as (SELECT
     userID,
     STUFF(
         (SELECT char(10) + 'Date added: ' + convert(varchar(10), dateAdded, 120) + ' || ' + 'Action: ' + action + ' || ' + cast(comments as varchar(max))
          from  [bullhorn1].[BH_UserComment]
          WHERE userID = a.userID
		  order by dateAdded desc
          FOR XML PATH (''))
          , 1, 1, '')  AS URLList
FROM  [bullhorn1].[BH_UserComment] AS a
GROUP BY a.userID)

--select * from tmp_4
, 
tmp_5 as (select userID 
	, case when (Cl.division = '' OR Cl.division is NULL) THEN '' ELSE concat('Department: ',Cl.division) END as Department
	, case when (Cl.status = '' OR Cl.status is NULL) THEN '' ELSE concat('Status: ',Cl.status) END as Status1
	, case when (cast(Cl.desiredCategories as varchar(max)) = '' OR Cl.desiredCategories is NULL) THEN '' ELSE concat('Designed Categories: ',Cl.desiredCategories) END as DesignedCategories
	, case when (cast(Cl.desiredSpecialties as varchar(max)) = '' OR Cl.desiredSpecialties is NULL) THEN '' ELSE concat('Desired Specialties: ',Cl.desiredSpecialties) END as DesiredSpecialties
	, case when (cast(Cl.desiredSkills as varchar(max)) = '' OR Cl.desiredSkills is NULL) THEN '' ELSE concat('Desired Skills: ',Cl.desiredSkills) END as DesiredSkills
from bullhorn1.BH_Client Cl where isPrimaryOwner = 1 and isDeleted = 0)
--select * from tmp_5

, tmp_6 as (select userID, concat(Status1,char(10),Department,char(10),DesignedCategories,char(10),DesiredSpecialties,char(10),DesiredSkills) as CombinedNote from tmp_5)
--select * from tmp_6

/* this is written for all custom required fields from Search Elect */
/*, tmp_6_1 as (select userID
	, concat(iif(address1 = '' or address1 is NULL,'',concat('Address 1: ',address1,' | '))
	,iif(city = '' or city is NULL,'',concat('City: ',city,' | '))
	,iif(state = '' or state is NULL,'',concat('State: ',state,' | '))
	,iif(cast(countryID as varchar(max)) = '' or countryID is NULL,'',concat('Country: ',tmp_country.COUNTRY,' | '))
	,iif(employmentPreference = '' or employmentPreference is NULL,'',concat('Employment Preference: ',employmentPreference))
	) as AdditionalNote 
	from bullhorn1.BH_UserContact UC 
	left join tmp_country on UC.countryID = tmp_country.CODE)
*/
, tmp_6_1 as (select userID
	, concat(iif(address1 = '' or address1 is NULL,'',concat('Address 1: ',address1,char(10)))
		,iif(city = '' or city is NULL,'',concat('City: ',city,char(10)))
		,iif(state = '' or state is NULL,'',concat('State: ',state,char(10)))
		,iif(cast(countryID as varchar(max)) = '' or countryID is NULL,'',concat('Country: ',tmp_country.COUNTRY,char(10)))
		,iif(employmentPreference = '' or employmentPreference is NULL,'',concat('Employment Preference: ',employmentPreference))
	) as AdditionalNote 
	from bullhorn1.BH_UserContact UC 
	left join tmp_country on UC.countryID = tmp_country.CODE)
--select * from tmp_6_1

, tmp_7(userID, phone) as (SELECT
     userID,
     STUFF(
         (SELECT iif(phone = '' or phone is NULL,'',concat(phone,',')) + 
		 iif(phone2 = '' or phone2 is NULL,'',concat(phone2,',')) + 
		 iif(phone3 = '' or phone3 is NULL,'',concat(phone3,',')) +
		 iif(mobile = '' or mobile is NULL,'',concat(mobile,',')) +
		 iif(workPhone = '' or workPhone is NULL or workPhone = '0','', workPhone)
          from  bullhorn1.BH_UserContact
          WHERE userID = a.userID
          FOR XML PATH (''))
          , 1, 0, '')  AS URLList
FROM  bullhorn1.BH_UserContact AS a
GROUP BY a.userID)


, tmp_7_1 (userID, phone) as (SELECT
     userID,
	 iif(right(phone,1)=',',left(phone,len(phone)-1),phone)
	 from tmp_7)

, tmp_doc0 (userid, name) as (select a.USERID, concat(a.clientCorporationFileID,'-co-doc',a.fileExtension) from bullhorn1.BH_ClientCorporationFile a)
--select * from tmp_5
--where a.type = 'Resume') ==> get all candidates files
, tmp_doc1 (userid, ResumeId) as (SELECT userid, STUFF((SELECT DISTINCT ',' + name from tmp_doc0 WHERE userid = a.USERID FOR XML PATH ('')), 1, 1, '')  AS URLList FROM tmp_doc0 AS a GROUP BY a.USERID)
--select * from tmp_6 --order by clientCorporationID
*/

with skill as (select c.contactid,ss.skill from Contacts c left join SkillInstances si on c.contactid = si.objectid  left join skills ss on si.skillid = ss.skillid)

select top 10
--select
	CC.CompanyId as 'contact-companyId'
	, CC.CompanyName as '(contact-companyname)'
	, CL.ContactId as 'contact-externalId'

	, case when ( CL.FirstName = '' or CL.FirstName is null) then 'No Firstname' else replace(CL.FirstName,'?','') end as 'contact-firstName'
	, case when ( CL.LastName = '' or  CL.LastName is null) then 'No Lastname' else replace(CL.LastName,'?','') end as 'contact-lastName'
	--, UC.middleName as 'contact-middleName'

	--, CL.Email as '(contact-email)'
	, concat(
		  case when (CL.Email like '%@%') THEN CL.Email ELSE '' END
		, case when (CL.Email like '%@%' and CL.Email2 like '%@%') THEN concat (', ',CL.Email2) else '' END	
	) as 'contact-email'
	
	--, CL.DirectTel as 'contact-phone1'
	--, CL.WorkTel as 'contact-phone2'
	--, CL.MobileTel as 'contact-phone3'
	--, CL.HomeTel as 'contact-phone4'
	,case when (CL.DirectTel = '' OR CL.DirectTel is NULL) THEN 
		(case when (CL.MobileTel != '' OR CL.MobileTel is not NULL) THEN CONCAT(CL.MobileTel,' ,',CL.WorkTel,' ,',CL.HomeTel) else concat(CL.WorkTel,',',CL.HomeTel) end)
	 	else concat(CL.DirectTel
			,case when (CL.MobileTel = '' OR CL.MobileTel is NULL) THEN '' ELSE CONCAT(', ',CL.MobileTel) END
			,case when (CL.WorkTel = '' OR CL.WorkTel is NULL) THEN '' ELSE CONCAT(' ,',CL.WorkTel) END
			,case when (CL.HomeTel = '' OR CL.HomeTel is NULL) THEN '' ELSE CONCAT(' ,',CL.HomeTel) END
	) END as 'contact-phone'
	--,concat(CL.DirectTel,',',CL.MobileTel,',',CL.WorkTel,',',CL.HomeTel) as 'contact-phone'
	
	--, as 'contact-owners'
	, CL.UserId as '(contact-owners-id)'
	, CL.UserName as '(contact-owners-name)'
	, CL.JobTitle as 'contact-jobTitle'
	--, CL.userId as 'Contact External ID'
	, at.Filename as 'contact-document'
	--, concat('BH Contact owners: ',UC2.name,char(10),e.AdditionalNote,char(10),f.CombinedNote,char(10),UC.lastNote_denormalized) as 'contact-Note'

	, concat(
		  case when (CL.Comments = '' OR CL.Comments is NULL) THEN '' ELSE concat ('Comments: ',CL.Comments,char(10)) END
		, case when (n1.NotesID = '' OR n1.NotesId is NULL) THEN '' ELSE concat ('NotesId: ',n1.NotesId,char(10)) END
		, case when (n.Text = '' OR n.Text is NULL) THEN '' ELSE replace(concat (n.Text,char(10)),'&amp; ','') END
	) as 'contact-comment'

	, concat(
		  case when (CL.Title = '' OR CL.Title is NULL) THEN '' ELSE concat ('Title: ',CL.Title,char(10)) END
		, case when (CL.Department = '' OR CL.Department is NULL) THEN '' ELSE concat ('Department: ',CL.Department,char(10)) END
		--, replace(skills.skill,'&amp; ','') as 'contact-skill'
		, case when (skills.skill = '' OR skills.skill is NULL) THEN '' ELSE concat ('Skills: ',replace(skills.skill,'&amp; ',''),char(10)) END
		, case when (CL.WebSite = '' OR CL.WebSite is NULL) THEN '' ELSE concat ('WebSite: ',CL.WebSite,char(10)) END
		, case when (CL.Address1 = '' OR CL.Address1 is NULL) THEN '' ELSE concat ('Address1: ',CL.Address1,char(10)) END
		, case when (CL.Address2 = '' OR CL.Address2 is NULL) THEN '' ELSE concat ('Address2: ',CL.Address2,char(10)) END
		, case when (CL.Address3 = '' OR CL.Address3 is NULL) THEN '' ELSE concat ('Address3: ',CL.Address3,char(10)) END
		, case when (CL.City = '' OR CL.City is NULL) THEN '' ELSE concat ('City: ',CL.City,char(10)) END
		, case when (CL.PostCode = '' OR CL.PostCode is NULL) THEN '' ELSE concat ('PostCode: ',CL.PostCode,char(10)) END
		, case when (CL.Location = '' OR CL.Location is NULL) THEN '' ELSE concat ('Location: ',CL.Location,char(10)) END
		, case when (CL.SubLocation = '' OR CL.SubLocation is NULL) THEN '' ELSE concat ('SubLocation: ',CL.SubLocation,char(10)) END
		, case when (CL.Country = '' OR CL.Country is NULL) THEN '' ELSE concat ('Country: ',CL.Country,char(10)) END
		, case when (CL.County = '' OR CL.County is NULL) THEN '' ELSE concat ('County: ',CL.County,char(10)) END
		, case when (CL.ContactStatus = '' OR CL.ContactStatus is NULL) THEN '' ELSE concat ('ContactStatus: ',CL.ContactStatus,char(10)) END
		, case when (CL.ContactSource = '' OR CL.ContactSource is NULL) THEN '' ELSE concat ('ContactSource: ',CL.ContactSource,char(10)) END
		, case when (CL.Sector = '' OR CL.Sector is NULL) THEN '' ELSE concat ('Sector: ',CL.Sector,char(10)) END
		, case when (CL.RegDate = '' OR CL.RegDate is NULL) THEN '' ELSE concat ('RegDate: ',CL.RegDate,char(10)) END
		, case when (CL.LastUpdate = '' OR CL.LastUpdate is NULL) THEN '' ELSE concat ('LastUpdate: ',CL.LastUpdate,char(10)) END
		, case when (CL.Segment = '' OR CL.Segment is NULL) THEN '' ELSE concat ('Segment: ',CL.Segment,char(10)) END
	) as 'contact-Note'

-- select top 10 *
-- select count(*) --143617
from Contacts CL
left join Companies CC ON CL.CompanyId = CC.CompanyId

left join (SELECT contactid, text = STUFF((SELECT char(10) + 'TEXT: ' + text + char(10) FROM notes b WHERE b.contactid = a.contactid FOR XML PATH('')), 1, 0, '') FROM notes a GROUP BY contactid) n on CL.contactid = n.contactid
left join (SELECT contactid, notesid = STUFF((SELECT ',' + notesid + char(10) FROM notes b WHERE b.contactid = a.contactid FOR XML PATH('')), 1, 1, '') FROM notes a GROUP BY contactid) n1 on CL.contactid = n1.contactid

left join (SELECT id, filename = STUFF((SELECT DISTINCT ',' + filename from Attachments WHERE id = a.id FOR XML PATH ('')), 1, 1, '') FROM Attachments a GROUP BY id) at on cl.contactid = at.Id
left join (SELECT contactid, skill = STUFF((SELECT skill + char(10) FROM skill b WHERE b.contactid = a.contactid FOR XML PATH('')), 1, 0, '') FROM skill a GROUP BY contactid) skills on CL.contactid = skills.contactid

WHERE CL.type = 'contact'
and CL.DESCRIPTOR < 3
--CL.Email != '' and CL.Email is not null and CL.Email2 != '' and CL.Email2 is not NULL
--CL.contactid = '271094-9983-13326'
-- n.text is not null
--CL.FirstName like '%Felice%'
--skills.skill is not null

/*
--left join tmp_3 b on ltrim(rtrim(cast(UC.ownerUserIDList as nvarchar(max)))) = cast(b.userID as nvarchar(max))

select * from bullhorn1.BH_Client Cl 
left join bullhorn1.BH_UserContact UC ON Cl.userID = UC.userID
where Cl.userID = 112 

select phone, phone2, phone3, workphone
from bullhorn1.BH_UserContact UC
where userID = 5429 or userID = 5430 or userID = 5431

*/