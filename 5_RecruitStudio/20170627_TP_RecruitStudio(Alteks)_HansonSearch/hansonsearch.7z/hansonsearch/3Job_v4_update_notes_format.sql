/*
with tmp_1(userID, email) as 
(select userID, REPLACE(ISNULL(email,'') + ',' + ISNULL(email2,'') + ',' + ISNULL(email3,''), ',,', ',') as email
from bullhorn1.BH_UserContact
 )
 --select * from tmp_1
 --select userID, email, CHARINDEX(email,',',0) from tmp_1
 , tmp_2(userID, email) as (
select userID, CASE WHEN CHARINDEX(',',email,1) = 1 THEN RIGHT(email, len(email)-1)
	ELSE email END as email
from tmp_1
)
 , tmp_3(userID, email) as (
select userID, CASE WHEN CHARINDEX(',',email,len(email)) = len(email) 
	THEN LEFT(email, CASE WHEN len(email) < 1 THEN 0 ELSE len(email) - 1 END)
	ELSE email END as email
from tmp_2
)

, Note as (
select jobPostingID
, concat('BH Job ID:',JP.jobPostingID,char(10)
, 'Position type: ',JP.type,char(10)
, 'Employment Type: ',JP.employmentType,char(10)
, 'Priority: ',JP.type,char(10)
, iif(JP.salary = '' or JP.salary is NULL,'',concat('Salary: ',JP.salary,char(10)))
, iif(JP.feeArrangement = '' or JP.feeArrangement is NULL,'',concat('Fee arrangement: ',JP.feeArrangement,char(10)))
, iif(JP.publishedCategoryID = '' or JP.publishedCategoryID is NULL,'',concat('Publish Category: ',JP.publishedCategoryID,' - ',CL.occupation,char(10)))
, iif(cast(JP.skills as varchar(max))= '' or JP.skills is NULL,'',concat('Required skills: ',JP.skills,char(10)))
, iif(JP.yearsRequired = '' or JP.yearsRequired is NULL,'',concat('Years required: ',JP.yearsRequired,char(10)))
, iif(CC.address1 = '' or CC.address1 is NULL,'',concat('Company address: ',CC.address1)) 
) as AdditionalNote
from bullhorn1.BH_JobPosting JP
left join bullhorn1.BH_CategoryList CL on JP.publishedCategoryID = CL.categoryID
left join bullhorn1.BH_ClientCorporation CC on JP.clientCorporationID = CC.clientCorporationID)


/* Add placement information under job posting */
, tmp_4 as (select jobPostingID
, concat('Status: ',PL.status,char(10)
, iif(PL.reportTo = '' or PL.reportTo is NULL,'',concat('Report to: ',PL.reportTo,char(10)))
, iif(PL.costCenter = '' or PL.costCenter is NULL,'',concat('Cost Center: ',PL.costCenter,char(10)))
, iif(PL.billingUserID = '' or PL.billingUserID is NULL,'',concat('Billing User: ',PL.billingUserID,' - ',UC.firstName,' ',UC.lastName))
, iif(cast(PL.dateBegin as varchar(10)) = '' or PL.dateBegin is NULL,'',concat('Start Date: ',convert(varchar(10),PL.dateBegin,120),char(10)))
, iif(cast(PL.dateEnd as varchar(10)) = '' or PL.dateEnd is NULL,'',concat('Scheduled End: ',convert(varchar(10),PL.dateBegin,120),char(10)))
, iif(PL.employeeType = '' or PL.employeeType is NULL,'',concat('Employee type: ',PL.employeeType,char(10)))
, iif(PL.fee = '' or PL.fee is NULL,'',concat('Placement Fee(%): ',PL.fee,char(10)))
, iif(PL.daysGuaranteed = '' or PL.daysGuaranteed is NULL,'',concat('Days Guaranteed: ',PL.daysGuaranteed,char(10)))
, iif(PL.daysProRated = '' or PL.daysProRated is NULL,'',concat('Days Pro-Rated: ',PL.daysProRated,char(10)))
, iif(cast(PL.dateClientEffective as varchar(10)) = '' or PL.dateClientEffective is NULL,'',concat('Effective Date: ',convert(varchar(10),PL.dateClientEffective,120),char(10)))
, iif(PL.clientBillRate = '' or PL.clientBillRate is NULL,'',concat('Bill Rate: ',PL.clientBillRate,char(10)))
, iif(PL.payRate = '' or PL.payRate is NULL,'',concat('Pay Rate: ',PL.payRate,char(10)))
, iif(PL.salaryUnit = '' or PL.salaryUnit is NULL,'',concat('Pay Unit: ',PL.salaryUnit,char(10)))
, iif(PL.clientOvertimeRate = '' or PL.clientOvertimeRate is NULL,'',concat('Overtime Bill Rate: ',PL.clientOvertimeRate,char(10)))
, iif(cast(PL.dateEffective as varchar(10)) = '' or PL.dateEffective is NULL,'',concat('Effective Date (pay rate info): ',convert(varchar(10),PL.dateEffective,120),char(10)))
, iif(PL.overtimeRate = '' or PL.overtimeRate is NULL,'',concat('Overtime Pay Rate: ',PL.overtimeRate,char(10)))
, iif(cast(PL.dateAdded as varchar(10)) = '' or PL.dateAdded is NULL,'',concat('Date added: ',convert(varchar(10),PL.dateAdded,120),' | ',PL.comments))
) as PlacementNote
from bullhorn1.BH_Placement PL
left join bullhorn1.BH_UserContact UC on PL.billingUserID = UC.userID)

, PlacementNote (jobPostingID, PlacementNote) as (SELECT
     jobPostingID,
     STUFF(
         (SELECT DISTINCT ' || ' + PlacementNote
          from  tmp_4
          WHERE jobPostingID = a.jobPostingID
          FOR XML PATH (''))
          , 1, 4, '')  AS URLList
FROM tmp_4 as a
GROUP BY a.jobPostingID)
*/

--SELECT top 50
 select
	  j.JobNumber as 'position-externalId'
	, j.ContactId as 'position-contactId'
	, j.JobTitle as 'position-title'
	
	, j.DisplayName as '(Contact Name)'
	, j.UserName as '(Job Owner)'
	, j.Company as '(Company Name)'
	
	--, j.PermanentJob as 'position-type' -- PERMANENT,INTERIM_PROJECT_CONSULTING,TEMPORARY,CONTRACT,TEMPORARY_TO_PERMANENT
	, case
		when j.PermanentJob is null then 'PERMANENT'
		when j.PermanentJob = '' then  'PERMANENT'
		when j.PermanentJob like '%active%' then 'PERMANENT'
		when j.PermanentJob like '%AD%' then 'PERMANENT'
		when j.PermanentJob like '%AM%' then 'PERMANENT'
		when j.PermanentJob like '%Contract%' then 'CONTRACT'
		when j.PermanentJob like '%Contract - 12 month fixed%' then 'CONTRACT'
		when j.PermanentJob like '%Corp/Finance%' then 'INTERIM_PROJECT_CONSULTING'
		when j.PermanentJob like '%Financial PR%' then 'INTERIM_PROJECT_CONSULTING'
		when j.PermanentJob like '%Freelance%' then 'TEMPORARY'
		when j.PermanentJob like '%Med ed%' then 'INTERIM_PROJECT_CONSULTING'
		when j.PermanentJob like '%Part Time%' then 'TEMPORARY'
		when j.PermanentJob like '%perm%' then 'PERMANENT'
		when j.PermanentJob like '%Permamaent %' then 'PERMANENT'
		when j.PermanentJob like '%Permamant %' then 'PERMANENT'
		when j.PermanentJob like '%Permanent%' then 'PERMANENT'
		when j.PermanentJob like '%PR%' then 'PERMANENT'
		when j.PermanentJob like '%speculative%' then 'INTERIM_PROJECT_CONSULTING'
		when j.PermanentJob like '%Team Leader%' then 'INTERIM_PROJECT_CONSULTING'
		when j.PermanentJob like '%Team Member %' then 'INTERIM_PROJECT_CONSULTING'
		when j.PermanentJob like '%telesales%' then 'INTERIM_PROJECT_CONSULTING'
		when j.PermanentJob like '%temp to permanent%' then 'TEMPORARY_TO_PERMANENT'
		when j.PermanentJob like '%Temporary%' then 'TEMPORARY'
		when j.PermanentJob like '%writing and account handl%' then 'INTERIM_PROJECT_CONSULTING'
	end as 'position-type'
	
	,  case when (j.FullTimeJob = 'Full Time' or j.FullTimeJob = '' or j.FullTimeJob is null) then 'FULL_TIME'
		when j.FullTimeJob = 'Part Time' then 'PART_TIME' 
		end as 'position-employmentType' --FULL_TIME,PART_TIME,CASUAL
	
	, j.JobStatus as 'Job Status (Start-End date)'
	--, CONVERT(VARCHAR(10),j.RegDate,120) as 'position-startDate'
	, case when j.startdate is null then CONVERT(VARCHAR(10),j.regdate,120) else CONVERT(VARCHAR(10),j.startdate,120) end as 'position-startdate'
	--, case when cast(j.JobStatus as nvarchar(max)) in ('Closed','Filled') then (cast(getdate() -1 as nvarchar(max))) else cast(j.JobStatus as nvarchar(max)) end as 'position-enddate'
	, case when j.JobStatus in ('Closed','Filled','Withdrawn') then CONVERT(VARCHAR(10),getdate() - 1,120) else '' end as 'position-enddate'
	
	, j.VacanciesCount as 'position-headcount'
	
	, j.Salary1 as 'position-actualSalary'
	, left(cast(j.VacancyDetails as varchar(max)),32000) as 'position-publicDescription'
	--, left(cast(j.description as varchar(max)),32000) as 'position-internalDescription'

	
	, at.filename as 'position-document'
	
	, concat (
		  case when (j.Sector = '' OR j.Sector is NULL) THEN '' ELSE concat ('Sector: ',j.Sector,char(10)) END
		, case when (j.Location = '' OR j.Location is NULL) THEN '' ELSE concat ('Location: ',j.Location,char(10)) END
		, case when (j.VacancyType = '' OR j.VacancyType is NULL) THEN '' ELSE concat ('VacancyType: ',j.VacancyType,char(10)) END
		, case when (j.Benefits = '' OR j.Benefits is NULL) THEN '' ELSE concat ('Benefits: ',j.Benefits,char(10)) END
		, case when (j.Fee = '' OR j.Fee is NULL) THEN '' ELSE concat ('Fee: ',j.Fee,char(10)) END
		, case when (j.VacancyId = '' OR j.VacancyId is NULL) THEN '' ELSE concat ('VacancyId: ',j.VacancyId,char(10)) END
		, case when (j.Department = '' OR j.Department is NULL) THEN '' ELSE concat ('Department: ',j.Department,char(10)) END
		, case when (j.Segment = '' OR j.Segment is NULL) THEN '' ELSE concat ('Segment: ',j.Segment,char(10)) END
		, case when (j.Postcode = '' OR j.Postcode is NULL) THEN '' ELSE concat ('Postcode: ',j.Postcode,char(10)) END
		, case when (j.Currency1 = '' OR j.Currency1 is NULL) THEN '' ELSE concat ('Currency1: ',j.Currency1,char(10)) END
		, case when (j.CompanyId = '' OR j.CompanyId is NULL) THEN '' ELSE concat ('CompanyId: ',j.CompanyId,char(10)) END
		, case when (j.SubLocation = '' OR j.SubLocation is NULL) THEN '' ELSE concat ('SubLocation: ',j.SubLocation,char(10)) END
	) as 'position-note'

-- SELECT count(*) --7870
from vacancies j
left join (SELECT id, filename = STUFF((SELECT DISTINCT ', ' + filename from Attachments WHERE id = a.id FOR XML PATH ('')), 1, 1, '') FROM Attachments a GROUP BY id) at on j.jobnumber = at.Id
--where j.FullTimeJob is not null

/*left join bullhorn1.BH_Client b on j.clientUserID = b.userID
left join tmp_3 c ON j.userID = c.userID
--left join bullhorn1.BH_UserContact UC on j.userID = UC.userID
left join PlacementNote PN on j.jobPostingID = PN.jobPostingID
left join Note on j.jobPostingID = note.jobPostingID
--where b.isPrimaryOwner = 1;
*/
/*
select jobPostingID, count(jobPostingID)
from bullhorn1.BH_Placement PL
group by jobPostingID having count(jobPostingID) >1

*/