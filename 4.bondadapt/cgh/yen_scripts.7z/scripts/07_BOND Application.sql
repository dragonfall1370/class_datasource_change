  
  -------05_JOB APPLICATION---------145,704----------
with cte
as
(
  SELECT  b.[4 RefNumber Numeric] as 'candidate-externalId'
  , c.[1 Job Ref Numeric] as 'job-externalId'
  , a.[1 Auto Ref Numeric] as 'application-externalId'
  , act.Description as 'stage' /*SHORTLISTED
				SENT
				FIRST_INTERVIEW
				SECOND_INTERVIEW
				OFFERED
				PLACEMENT_PERMANENT
				PLACEMENT_CONTRACT
				PLACEMENT_TEMP
				ONBOARDING*/
  , convert(date,left([16 Lastactnda Date], 10), 103) as 'actioned-date' --associated_date
 -- , a.UniqueID
FROM F13 as a
left JOIN F01 as b on (b.UniqueID = a.[4 Candidate Xref] /*or b.[4 RefNumber Numeric] = a.[5 Cand id Numeric]*/)
left JOIN F03 as c on c.UniqueID = a.[6 Job Ref Xref]
JOIN(select * from codes where Codegroup = 130) as act on act.Code = left([19 LastAction Codegroup 130], 2)
where a.[4 Candidate Xref] is NOT NULL

union all

 SELECT  b.[4 RefNumber Numeric] as 'candidate-externalId'
  , c.[1 Job Ref Numeric] as 'job-externalId'
  , a.[1 Auto Ref Numeric] as 'application-externalId'
  , act.Description as 'stage' /*SHORTLISTED
				SENT
				FIRST_INTERVIEW
				SECOND_INTERVIEW
				OFFERED
				PLACEMENT_PERMANENT
				PLACEMENT_CONTRACT
				PLACEMENT_TEMP
				ONBOARDING*/
  , convert(date,left([16 Lastactnda Date], 10), 103) as 'actioned-date' --associated_date
FROM F13 as a
left JOIN F01 as b on (b.[4 RefNumber Numeric] = a.[5 Cand id Numeric])
LEFT JOIN F03 as c on c.UniqueID = a.[6 Job Ref Xref]
JOIN(select * from codes where Codegroup = 130) as act on act.Code = left([19 LastAction Codegroup 130], 2)
where a.[4 Candidate Xref] is NULL
)
select 'BB - ' + cast([candidate-externalId] as varchar(20)) as 'candidate-externalId'
	, 'BB - ' + cast([job-externalId] as varchar(20)) as 'job-externalId'
	, 'BB - ' + cast([application-externalId] as varchar(20)) as 'application-externalId'
	--, stage
	, x.[VincereStage]
	, [actioned-date]
from cte
left join cgh.[dbo].[app_stage_mapping] as x on x.[BondStage] = cte.stage
where  [candidate-externalId] is not null
and [job-externalId] is not null