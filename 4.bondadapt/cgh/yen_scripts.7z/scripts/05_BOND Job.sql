


----------------------------04_BOND JOB-----------12,655----(868 temp job(jobtype =6,7,16) -> skip)-----11,787perm--
with scd as
(
select distinct UniqueID
  , REVERSE(LEFT(REVERSE([Relative Document Path]), CHARINDEX('\', REVERSE([Relative Document Path])) - 1)) as FN
from F03Docs3
), cd as
(
select UniqueID
 ,  STUFF((select ', ' + x.FN from scd x where x.uniqueID = scd.UniqueID for xml path('')), 1,2,'') as FN
FROM scd
GROUP BY UniqueID
)

select coalesce('BB - ' +  cast(con.[4 RefNumber Numeric] as varchar(20)), 'BB00000') as 'position-contactId'--[20 Contact Xref]
  , 'BB - ' + cast(co.[8 Reference Numeric] as varchar(20)) as 'position-companyId'--[2 Site Xref]
  , case when [3 Job Title Alphanumeric] is NULL then 'Blank position title ' + cast(a.[1 Job Ref Numeric] as varchar(20))
         when [3 Job Title Alphanumeric] is not null and rnk = 1 then [3 Job Title Alphanumeric] else
                'dup_' +  cast(a.[1 Job Ref Numeric] as varchar(20)) + '_' + [3 Job Title Alphanumeric] end as 'position-title'
  --, [185 JobTitle Alphanumeric]
  , coalesce([74 No Reqd Numeric], 1) as 'position-headcount'
  , coalesce(jo.[75 Email Alphanumeric], '') as 'position-owners'--[7 Consultant Xref]
  --, jt.Description as 'position-type' --[6 Job Type Codegroup 178]--5 PERMANENT, INTERIM_PROJECT_CONSULTING, TEMPORARY, CONTRACT. TEMPORARY_TO_PERMANENT--default PERMANENT
  , CASE WHEN [6 Job Type Codegroup 178] in('01', '08', '09') THEN 'CONTRACT'--'RPO'
         WHEN [6 Job Type Codegroup 178] in('10', '14', '15') THEN 'TEMPORARY_TO_PERMANENT'--'OPRA'
		 WHEN [6 Job Type Codegroup 178] in('03', '04') THEN 'INTERIM_PROJECT_CONSULTING'--'Perm Contingent'
		 WHEN [6 Job Type Codegroup 178] in('02', '05') THEN 'PERMANENT'--'Perm Retained'
		 else 'PERMANENT'
	END as 'position-type'
  , CASE [196 WorkType Codegroup 165]
    WHEN 1 THEN 'FULL_TIME'
	WHEN 2 THEN 'PART_TIME'
	WHEN 3 THEN 'CASUAL'
	WHEN 4 THEN 'CASUAL' else 'FULL_TIME'
    END as 'position-employmentType'--6 --FULL_TIME, PART_TIME, CASUAL --default FULL_TIME
  , coalesce([92 Notes Alphanumeric],'') as 'position-comment'
  --,  as 'position-currency'--$
  --, [13 package Fr Numeric] as 'package from-to'
  , coalesce([147 Salary 2 Numeric],'') as 'position_actualSalary'
  --, [43 PAY STD Numeric] as 'position-payRate' --??or [33 Charge Std Numeric]
  --, [194 Duration Numeric] as 'position-contractLength' --days
  --, wu.Description as 'position-contractUnit'--[158 UOM Codegroup 141]
  --, np.Description as 'position-noticePeriod'--[198 Notice Codegroup 171]
  --,  as 'position-publicDescription'
--  ,  as 'positoin-internalDescription'
  , 'BB - ' +  cast(a.[1 Job Ref Numeric] as varchar(20)) as 'position-externalId'
  , convert(date,[21 Created Date],103) as 'position-startDate'
  , coalesce(convert(date, [154 Job Closed Date], 103),'') as 'position-endDate'
  , coalesce(cd.FN, '') 'position-document'--filename
  , 'Job External ID: BB - ' + cast(a.[1 Job Ref Numeric] as varchar(20)) + char(10)  
	+ coalesce('Package Details: ' + a.[31 PackageNte Alphanumeric] + char(10), '') 
	+ coalesce('Contact Flat Fee $: ' + a.[39 Flat Fee Numeric] + char(10), '')
	+ coalesce('Job Fee %: ' + a.[41 Fee % Numeric] + char(10), '')  as 'position-note'

from(select ROW_NUMBER() over(partition by [3 Job Title Alphanumeric] order by [1 Job Ref Numeric]) as rnk, * from F03 )as a
LEFT JOIN 
(
	SELECT UniqueID, [38 Phone Alphanumeric]
	  , [121 EmailCont Alphanumeric]
	  , [4 RefNumber Numeric]
    FROM F01 
	WHERE [16 Site Xref] is not null 
) as con on con.UniqueID = a.[20 Contact Xref]
LEFT JOIN F02 as co on co.UniqueID = a.[2 Site Xref]
LEFT JOIN(SELECT * FROM CODES WHERE Codegroup = 178) as jt on jt.Code = a.[6 Job Type Codegroup 178]
LEFT JOIN F17 as jo on jo.UniqueID = a.[7 Consultant Xref]
LEFT JOIN(SELECT * FROM CODES WHERE Codegroup = 141) as wu on wu.Code = a.[158 UOM Codegroup 141]
LEFT JOIN(SELECT * FROM CODES WHERE Codegroup = 171) as np on np.Code = a.[198 Notice Codegroup 171]
LEFT JOIN cd on cd.UniqueID = a.UniqueID
where [6 Job Type Codegroup 178] <> 16 --NOT migrate job type = other
--where a.[6 Job Type Codegroup 178]not in('06','07','16')--MIGRATE PERMANENT JOBS ONLY
