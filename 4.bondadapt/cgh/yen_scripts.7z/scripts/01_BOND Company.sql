








--------------------01.Company-------14,747-----------------------------------------------
--https://hrboss.atlassian.net/wiki/spaces/SB/pages/580157441/15.2.4.+Bond+Adapt+V9
;with sc as
(
	SELECT t2.UniqueID,
			F17.[75 Email Alphanumeric]as consultant
	FROM F02 t2 
	OUTER APPLY 
	(
		SELECT  Item as Consultant
		FROM    cgh.dbo.[DelimitedSplitN4K] (t2.[4 Consultant Xref],'~')
		where t2.[4 Consultant Xref] is not NULL
	)t
	join F17 on F17.UniqueID = t.Consultant
) 
, c as(
  SELECT UniqueID,
        STUFF((select ', ' + x.Consultant from sc x where x.uniqueID = sc.UniqueID for xml path('')), 1,2,'') as Consultant
  FROM sc
  GROUP BY UniqueID
),
scc as
(
	SELECT t2.UniqueID
			, c.VinCountryCode
			, c.description
			, ROW_NUMBER() over(partition by UniqueID order by Vincountrycode) rnk
			
	FROM F02 t2 
	OUTER APPLY 
	(
		SELECT  Item as code
		FROM    cgh.dbo.[DelimitedSplitN4K] (t2.[137 Country Codegroup 146],'~')
		where t2.[137 Country Codegroup 146] is not NULL
	)t
	join cgh.dbo.[CountryCodeMapping]  as c on c.Code = t.code 
) 
, cc as(
  SELECT VinCountryCode, UniqueID, Description
  FROM scc
  WHERE rnk = 1
),
scd as
(
select distinct UniqueID
  , REVERSE(LEFT(REVERSE([Relative Document Path]), CHARINDEX('\', REVERSE([Relative Document Path])) - 1)) as FN
from F02Docs2
), cd as
(
select UniqueID
 ,  STUFF((select ', ' + x.FN from scd x where x.uniqueID = scd.UniqueID for xml path('')), 1,2,'') as FN
FROM scd
GROUP BY UniqueID
)
----------------------------------------https://hrboss.atlassian.net/wiki/spaces/SB/pages/19071426/Requirement+specs+Company+import--------------------------------------------------------------
SELECT 'BB - ' + cast(a.[8 Reference Numeric] as varchar(20)) as 'company-externalId'
	, CASE WHEN CompanyName IS NULL THEN 'No Company Name - ' + a.UniqueID
	    WHEN CompanyName IS NOT NULL AND rnk = 1 THEN CompanyName
		ELSE CompanyName + ' - Duplicate - ' + a.UniqueID
	END as 'company-name'

	, CASE WHEN a.[2 Type Codegroup   2] = 1 THEN coalesce(client_office.[35 officeadd Alphanumeric], '')
	       ELSE coalesce(a.[25 Address1+2 Alphanumeric] + ', ', '') END
	+  CASE WHEN cc.VinCountryCode IS NULL AND a.[52 State - M Codegroup  51] is NULL THEN '' ELSE
		coalesce(sb.[1 Suburb Alphanumeric], a.[128 Suburb Xref]  , '') 
		+ coalesce(', ' + a.[52 State - M Codegroup  51], '')  + ' ' 
		+ coalesce(a.[33 Postcode Alphanumeric], '')
	 end as 'company-locationAddress'
	, CASE WHEN cc.VinCountryCode IS NULL AND a.[52 State - M Codegroup  51] is NULL THEN '' ELSE
		coalesce(sb.[1 Suburb Alphanumeric], a.[128 Suburb Xref], '') 
		+ coalesce(', ' + a.[52 State - M Codegroup  51], '')  + ' ' 
		+ coalesce(a.[33 Postcode Alphanumeric], '') 
		+ case when cc.Description <> 'Australia' then coalesce(' ' + cc.Description, '') else '' end
	 END as 'company-locationName'
	, coalesce(cc.VinCountryCode, '') as 'company-locationCountry' --[137 Country Codegroup 146]
	, coalesce(a.[52 State - M Codegroup  51],'') 'company-locationState'
	, coalesce(sb.[1 Suburb Alphanumeric], a.[128 Suburb Xref], '') as 'company-locationDistrict'
	, coalesce(a.[33 Postcode Alphanumeric], '') as 'company-locationZipCode'
	--, 'company-nearestTrainStation'
	, coalesce(hq.[1 Name Alphanumeric], '') as 'company-headQuarter'
	, coalesce(a.[28 Phone Alphanumeric],'') as 'company-switchBoard'
	, coalesce(client_office.[36 office ph Alphanumeric], '') as 'company-phone'
	, CASE WHEN a.[2 Type Codegroup   2] = 1 THEN coalesce(client_office.[37 office fax Alphanumeric], '')
	       ELSE coalesce(a.[29 Fax Alphanumeric],'')
	  END as 'company-fax'
	, coalesce(a.[135 Website Alphanumeric],'') as 'company-website'
	, coalesce(c.Consultant, '') as 'company-owner'
	, coalesce(cd.FN, '') 'company-document'--filename
	/*, 'Company External ID: BB - ' + cast(a.[8 Reference Numeric] as varchar(20)) + char(10)  
	+ coalesce('Company Owner: ' + c.Consultant + char(10), '')
	+ coalesce('Company Short Name: ' + a.[22 Shortname Alphanumeric] + char(10), '')
	+ coalesce('Created Date: ' + convert(nvarchar(20), a.[9 Created Date],103) + char(10), '')
	+ coalesce('A.C.N: ' + a.[80 A.C.N. Alphanumeric] + char(10), '')
	+ coalesce('A.B.N: ' + a.[81 A.B.N. Alphanumeric] + char(10), '')
	+ coalesce('Company Status: ' + com_stat.Description + char(10), '')
	+ coalesce('Company Source: ' + com_source.Description + char(10), '')
	+ coalesce('Parent Company: ' + pc.[1 Name Alphanumeric] + char(10), '')
	+ coalesce('Company current Client: ' + cur_client.[1 Name Alphanumeric] + char(10), '')
	+ coalesce('Perm Fee %: ' + a.[47 Perm Fee % Numeric] + char(10), '')
	+ coalesce('Margin Fee %: ' + a.[101 C Margin % Numeric] + char(10), '')
	  as 'company-note'*/
	 
FROM (
 SELECT LTRIM(RTRIM([1 Name Alphanumeric])) as CompanyName
    , ROW_NUMBER() OVER(PARTITION BY LTRIM(RTRIM([1 Name Alphanumeric])) ORDER BY UniqueID) as rnk
	, *
 FROM F02
 WHERE [2 Type Codegroup   2] = 2 --migrate site only
 and [1 Name Alphanumeric] not like 'xx%'
  ) as a
  LEFT JOIN(SELECT * FROM CODES WHERE Codegroup = 5) as b on b.Code = a.[3 Status Codegroup   5]
  LEFT JOIN c on c.UniqueID = a.UniqueID --consultant
  LEFT JOIN cc on cc.UniqueID = a.UniqueID --countrycode
  LEFT JOIN F39 as sb on sb.UniqueID = a.[128 Suburb Xref]
  LEFT JOIN F02 as hq on hq.UniqueID = a.[23 Client Xref]
  LEFT JOIN F12 as client_office on client_office.UniqueID = a.[6 Office Xref]
  LEFT JOIN cd as cd on cd.UniqueID = a.UniqueID
  --LEFT JOIN (SELECT * FROM CODES WHERE Codegroup = 5) as com_stat on com_stat.Code = a.[3 Status Codegroup   5]
  --LEFT JOIN (SELECT * FROM CODES WHERE Codegroup = 8) as com_source on com_source.Code = a.[13 Source Codegroup   8]
  --LEFT JOIN (SELECT [1 Name Alphanumeric], UniqueID FROM F02 WHERE [32 Parent Xref] is NOT NULL) as pc on a.[32 Parent Xref] = pc.UniqueID
  --LEFT JOIN (SELECT [1 Name Alphanumeric], UniqueID FROM F02 WHERE [23 Client Xref] is NOT NULL) as cur_client on a.[23 Client Xref] = cur_client.UniqueID
WHERE 1 = 1
UNION ALL select 'BB00000','Default Blank Company','','', '','','','','','','','','','','This is Blank Company from Data Import'

