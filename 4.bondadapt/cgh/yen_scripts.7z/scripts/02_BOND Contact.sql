





--------------------02.Contact-------------36,585-----------------------------------------
with si as
(
	SELECT t2.UniqueID,
			F17.[75 Email Alphanumeric] as consultant
	FROM F01 t2 
	OUTER APPLY 
	(
		SELECT  Item as Consultant
		FROM    cgh.dbo.[DelimitedSplitN4K] (t2.[105 Consultant Xref],'~')
		where t2.[105 Consultant Xref] is not NULL
	)t
	join F17 on F17.UniqueID = t.Consultant
) 
, i as(
  SELECT UniqueID,
        STUFF((select ', ' + x.Consultant from si x where x.uniqueID = si.UniqueID for xml path('')), 1,2,'') as Consultant
  FROM si
  GROUP BY UniqueID
),
scd as
(
select distinct UniqueID
  , REVERSE(LEFT(REVERSE([Relative Document Path]), CHARINDEX('\', REVERSE([Relative Document Path])) - 1)) as FN
from F01Docs1
), cd as
(
select UniqueID
 ,  STUFF((select ', ' + x.FN from scd x where x.uniqueID = scd.UniqueID for xml path('')), 1,2,'') as FN
FROM scd
GROUP BY UniqueID
),
 px as
(---extract candidate status
	SELECT t2.UniqueID, item, ItemNumber
	FROM F01 t2 
	OUTER APPLY 
	(
		SELECT  *
		FROM    cgh.dbo.[DelimitedSplitN4K] (t2.[38 Phone Alphanumeric],'~')
		where t2.[38 Phone Alphanumeric] is not NULL
	)t
) 
--
-----------------------------------https://hrboss.atlassian.net/wiki/spaces/SB/pages/19071424/Requirement+specs+Contact+import------------------------------------------------
SELECT  CASE WHEN com.[8 Reference Numeric] IS NULL THEN 'BB00000' ELSE 'BB - ' + cast(com.[8 Reference Numeric] as varchar(20)) END as 'contact-companyId'
	 , coalesce(LEFT(ContactName, space_position), '') as 'contact-firstName'
	 , coalesce(SUBSTRING(ContactName, space_position, datalength(ContactName) - space_position), '') as 'contact-lastName'
	 , CASE WHEN [27 Title Codegroup  16] = 'MIS' THEN 'MISS'
	        WHEN [27 Title Codegroup  16] IS NULL THEN ''
	        ELSE  [27 Title Codegroup  16] 
	  END as 'contact-title'--not support this field via app import???
	 , coalesce(i.Consultant, '') 'contact-owners'
	 --, 'contact-Note'
	 --, 'contact-comment'
	 , coalesce(px1.item, '') as 'contact-phone'
	 , CASE when [121 EmailCont Alphanumeric] is NULL then cast(a.[4 RefNumber Numeric] as varchar(20)) + '@no_email.io'
	    WHEN [121 EmailCont Alphanumeric] IS NOT NULL AND rnk_email = 1 THEN [121 EmailCont Alphanumeric]
		ELSE 'dup_' +  cast(a.[4 RefNumber Numeric] as varchar(20)) + '_' + [121 EmailCont Alphanumeric]  
	END as 'contact-email'
	-- , 'contact-linkedin'
	 --, 'contact-skype'
	 , coalesce([96 JobTitle Alphanumeric], '') as 'contact-jobTitle'
	 , 'BB - ' + cast(a.[4 RefNumber Numeric] as varchar(20)) as 'contact-externalId'
	 , coalesce(cd.FN, '') as 'contact-document'
	 , case when charindex('~', [66 Alert Alphanumeric]) = 1 then '' 
	   else coalesce('Contact Alert: ' + case when charindex('~', [66 Alert Alphanumeric]) > 0 then left([66 Alert Alphanumeric], charindex('~', [66 Alert Alphanumeric]) - 1) else [66 Alert Alphanumeric] end + char(10), '') 
	   end as 'contact-note'
	 
	  
FROM
(
select 
	  LTRIM(RTRIM([1 Name Alphanumeric])) as ContactName,
	  case when CHARINDEX(' ', LTRIM(RTRIM([1 Name Alphanumeric]))) = 0 
	  then CHARINDEX(' ', LTRIM(RTRIM([1 Name Alphanumeric]))) 
	  else CHARINDEX(' ', LTRIM(RTRIM([1 Name Alphanumeric]))) 
	  end as space_position
	  , ROW_NUMBER() OVER(PARTITION BY LTRIM(RTRIM([121 EmailCont Alphanumeric])) ORDER BY UniqueID) as rnk_email
	  , coalesce([16 Site Xref], [43 Client Xref]) as companyid
	  , *      
from F01
where [16 Site Xref] is not null 
	and [28 Created Date] <>'00/01/1901' --2 record only
	and [1 Name Alphanumeric] not like 'xx%'
	and 
	(
		convert(date, [28 Created Date], 103) >= '2013-01-01'
		or
		(
		convert(date, [28 Created Date], 103) < '2013-01-01'
		and (UniqueID in(select [20 Contact Xref] from F03 ) or [41 Last Conta Date] >= '2013-01-01') 
		)
	)
) as a
LEFT JOIN(SELECT * FROM CODES WHERE Codegroup = 4) as c on c.Code = a.[3 Status Codegroup   4]
LEFT JOIN i on i.UniqueID = a.UniqueID
LEFT JOIN F02 as com on com.UniqueID = a.companyid
LEFT JOIN cd on cd.UniqueID = a.UniqueID
left join(select * from px where px.ItemNumber = 2) as px1 on px1.uniqueid = a.uniqueid
