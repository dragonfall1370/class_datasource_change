

--------------------03.Candidate---------------108,306---------------------------------------
;with y as
(---extract candidate status
	SELECT t2.[4 Candidate Xref],
			c.description
	FROM F13 t2 
	OUTER APPLY 
	(
		SELECT  Item 
		FROM    cgh.dbo.[DelimitedSplitN4K] (t2.[19 LastAction Codegroup 130],'~')
		where t2.[19 LastAction Codegroup 130] is not NULL
	)t
	join (select * from codes where codegroup = 130) as c on c.code = t.Item
	where c.Code in(16,35,36,39,40,41,42,43,44,45,46,47,51,52)
) 
, yy as(
  SELECT [4 Candidate Xref],
        STUFF((select ', ' + x.description from y x where x.[4 Candidate Xref] = y.[4 Candidate Xref] for xml path('')), 1,2,'') as description
  FROM y
  GROUP BY [4 Candidate Xref]
), yyy as(
select [4 Candidate Xref]
 , case when charindex(',', description) <> 0 then SUBSTRING(description, 1, charindex(',', description) - 1) else description end as last_action
 , case when charindex(',', description) <> 0 then substring(description, charindex(',', description) + 1, DATALENGTH(description) - charindex(',', description)) end as penultimate_action
from yy
)
, si as
(
	SELECT t2.UniqueID,
			F17.[75 Email Alphanumeric] as consultant
	FROM F01 t2 
	OUTER APPLY 
	(
		SELECT  Item as Consultant
		FROM    cgh.dbo.[DelimitedSplitN4K] (t2.[105 Consultant Xref],'~')
		where t2.[105 Consultant Xref] is not NULL
	)t
	join F17 on F17.UniqueID = t.Consultant
) 
, i as(
  SELECT UniqueID,
        STUFF((select ', ' + x.Consultant from si x where x.uniqueID = si.UniqueID for xml path('')), 1,2,'') as Consultant
  FROM si
  GROUP BY UniqueID
),
scc as
(
	SELECT t2.UniqueID
			, c.VinCountryCode
			, c.description
			, ROW_NUMBER() over(partition by UniqueID order by Vincountrycode) rnk
			
	FROM F01 t2 
	OUTER APPLY 
	(
		SELECT  Item as code
		FROM    cgh.dbo.[DelimitedSplitN4K] (t2.[237 Country Codegroup 146],'~')
		where t2.[237 Country Codegroup 146] is not NULL
	)t
	join cgh.dbo.[CountryCodeMapping]  as c on c.Code = t.code 
) 
, cc as
(
  SELECT VinCountryCode, UniqueID, Description
  FROM scc
  WHERE rnk = 1
), sskill as
(
	SELECT t2.UniqueID,
			c.[1 Attribute Alphanumeric] as Skill
	FROM F01 t2 
	OUTER APPLY 
	(
		SELECT  Item as Skill
		FROM    cgh.dbo.[DelimitedSplitN4K] (t2.[151 Skills Xref],'~')
		where t2.[151 Skills Xref] is not NULL
	)t
	left join F12 as c on c.UniqueID = t.Skill
) 
, skill as(
  SELECT UniqueID,
        STUFF((select ', ' + x.Skill from sskill x where x.uniqueID = sskill.UniqueID for xml path(''),type).value('(./text())[1]','varchar(max)'), 1,2,'') as Skill
  FROM sskill
  GROUP BY UniqueID
), jobhist
as(
select b.[1 Name Alphanumeric] as company
	, a.[4 Start Date Date] as startdate
	, a.[5 End Date Date] as enddate
	, a.[79 Duration Numeric] as duration
	, a.[27 Hist Ref Numeric] as id
	, a.[6 Job Title Alphanumeric] as job
	, a.[1 Candidate Xref] 
	, row_number() over(partition by [1 Candidate Xref] order by a.[4 Start Date Date] desc) as rnk
from f04 as a
JOIN F02 as b on b.UniqueID = a.[2 Site Xref]
where exists(select 1 from F01 as x where x.UniqueID = a.[1 Candidate Xref])
)
,
scd as
(
select distinct UniqueID
  , REVERSE(LEFT(REVERSE([Relative Document Path]), CHARINDEX('\', REVERSE([Relative Document Path])) - 1)) as FN
from F01Docs1
), cd as
(
select UniqueID
 ,  STUFF((select ', ' + x.FN from scd x where x.uniqueID = scd.UniqueID for xml path('')), 1,2,'') as FN
FROM scd
GROUP BY UniqueID
)
,
 px as
(---extract candidate status
	SELECT t2.UniqueID, item, ItemNumber
	FROM F01 t2 
	OUTER APPLY 
	(
		SELECT  *
		FROM    cgh.dbo.[DelimitedSplitN4K] (t2.[38 Phone Alphanumeric],'~')
		where t2.[38 Phone Alphanumeric] is not NULL
	)t
) 
-----------------------------------https://hrboss.atlassian.net/wiki/spaces/SB/pages/18284908/Requirement+specs+Candidate+import------------------------------------------------
SELECT CASE [249 WorkType Codegroup 165] 
       WHEN NULL THEN 'FULL_TIME'
	   WHEN 1 THEN 'FULL_TIME'
	   WHEN 2 THEN 'PART_TIME'
	   WHEN 3 THEN 'LABOUR_HIRE'
	   WHEN 4 THEN 'CASUAL'
	   else 'FULL_TIME'
      END as 'candidate-employmentType' ----FULL_TIME, PART_TIME, CASUAL --default FULL_TIME, 
     , case when [27 Title Codegroup  16] in('MIS') THEN 'MISS'
	       when [27 Title Codegroup  16] in('MS') THEN 'MS'
		   when [27 Title Codegroup  16] in('MR') THEN 'MR'
		   when [27 Title Codegroup  16] in('MRS') THEN 'MRS'
		   when [27 Title Codegroup  16] in('DR', 'SIR', 'THE', 'PRO') THEN 'DR'
		   else ''
	  end  as 'candidate-title'
	 , case when  LEFT(ContactName, space_position) = '' then  SUBSTRING(ContactName, space_position, datalength(ContactName) - space_position)  else LEFT(ContactName, space_position) end as 'candidate-firstName'
	 , SUBSTRING(ContactName, space_position, datalength(ContactName) - space_position) as 'candidate-lastName'
	 , [26 Pref Name Alphanumeric] as 'candidate-preferName'
	 , coalesce(i.Consultant, '') as 'candidate-owners'
	 , coalesce([251 JobTitle Alphanumeric], jh1.job, [96 JobTitle Alphanumeric],'') as 'candidate-jobTitle1'
	 --, coalesce(CONVERT(date, replace([39 DOB Date], '00/01/1901', NULL), 103), '') as 'candidate-dob'
	 , coalesce(cc.VinCountryCode, '') as 'candidate-citizenship'
	 , CASE WHEN primary_email IS NULL THEN cast(a.[4 RefNumber Numeric] as varchar(20)) + '@no_email.io'
	        WHEN primary_email IS NOT NULL AND rnk_email = 1 THEN primary_email
		    ELSE 'dup_' +  cast(a.[4 RefNumber Numeric] as varchar(20)) + '_' + primary_email
	   END as 'candidate-email'
	 , work_email as 'candidate-workEmail'
	 , coalesce(px3.item, '') as 'candidate-phone'
	 , coalesce(px4.item, '') as 'candidate-mobile'
	 , coalesce(px1.item, '') as 'candidate-homePhone'
	 , coalesce(px2.item, '') as 'candidate-workPhone'
	 , coalesce([202 Address1+2 Alphanumeric], [34 Address Alphanumeric], '') 
	 + case when coalesce(F39.[1 Suburb Alphanumeric], [203 Suburb Xref], '') = '' then '' else coalesce(F39.[1 Suburb Alphanumeric], [203 Suburb Xref], '') + ', ' end
	 + case when coalesce([204 State Codegroup  51], [35 State Codegroup  51], '') = '' then '' else coalesce([204 State Codegroup  51], [35 State Codegroup  51], '') + ' ' end
	 + case when coalesce([205 PC Alphanumeric], [23 Postcode Alphanumeric], '') = '' then '' else coalesce([205 PC Alphanumeric], [23 Postcode Alphanumeric], '') + ', ' end
	 + coalesce(cc.VinCountryCode, '')
	 as 'candidate-address'--concat state zip code and country??
	 , coalesce(F39.[1 Suburb Alphanumeric], [203 Suburb Xref], '') as 'candidate-city'--[203 Suburb Xref]
	 , coalesce([204 State Codegroup  51], [35 State Codegroup  51], '') as 'candidate-State'
	 , coalesce([205 PC Alphanumeric], [23 Postcode Alphanumeric], '') as 'candidate-zipCode'
	 --, 'candidate-currency'
	 , coalesce(skill.Skill,'') as 'candidate-Skill'-- [151 Skills Xref]	 
	 , coalesce([18 Package Numeric],'') as 'candidate-currentSalary'
	 , coalesce('Job HistoryId & Duration ' + cast(jh1.id as varchar(30)) + coalesce(' - ' + jh1.duration, '')
	 + '; ' + cast(jh2.id as varchar(30)) + coalesce(' - ' + jh2.duration, '')
	 + '; ' + cast(jh3.id as varchar(30)) + coalesce(' - ' + jh3.duration, '')
	 + coalesce(char(10) + jhs.FN, ''),'') as 'candidate-workHistory'
	 , coalesce(jh1.company,'') as 'candidate-company1'
	 , coalesce(convert(date, jh1.startdate, 103), '') as 'candidate-startDate1'
	 , coalesce(convert(date, jh1.enddate, 103), '') as 'candidate-endDate1'
	 , coalesce(jh2.company,'') as 'candidate-company2'
	 , coalesce(convert(date, jh2.startdate, 103), '') as 'candidate-startDate2'
	 , coalesce(convert(date, jh2.enddate, 103), '') as 'candidate-endDate2'
	 , coalesce(jh2.job ,'')as 'candidate-jobTitle2'
	 , coalesce(jh3.company,'') as 'candidate-company3'
	 , coalesce(convert(date, jh3.startdate, 103),'') as 'candidate-startDate3'
	 , coalesce(convert(date, jh3.enddate, 103),'') as 'candidate-endDate3'
	 , coalesce(jh3.job,'') as 'candidate-jobTitle3'
	 , coalesce(cd.FN,'') as 'candidate-document'
	 , 'BB - ' + cast(a.[4 RefNumber Numeric] as varchar(20)) as 'candidate-externalId'
	 , case when charindex('~', [66 Alert Alphanumeric]) = 1 then '' 
	   else coalesce('Candidate Alert: ' + case when charindex('~', [66 Alert Alphanumeric]) > 0 then left([66 Alert Alphanumeric], charindex('~', [66 Alert Alphanumeric]) - 1) else [66 Alert Alphanumeric] end + char(10), '')
	   end as 'candidate-note'
	  
FROM
(
select 
	  LTRIM(RTRIM([1 Name Alphanumeric])) as ContactName,
	  case when CHARINDEX(' ', LTRIM(RTRIM([1 Name Alphanumeric]))) = 0 
	  then CHARINDEX(' ', LTRIM(RTRIM([1 Name Alphanumeric]))) 
	  else CHARINDEX(' ', LTRIM(RTRIM([1 Name Alphanumeric]))) 
	  end as space_position
	  , ROW_NUMBER() OVER(PARTITION BY LTRIM(RTRIM(primary_email)) ORDER BY UniqueID) as rnk_email
	  , *      
from 
(
	select *
	 ,replace(case when charindex('~', [33 E-Mail Alphanumeric]) >= 10 then substring([33 E-Mail Alphanumeric], 1, charindex('~', [33 E-Mail Alphanumeric])) else [33 E-Mail Alphanumeric] end, '~', '') as primary_email
     ,replace(case when charindex('~', [33 E-Mail Alphanumeric]) >= 10 then substring([33 E-Mail Alphanumeric], charindex('~', [33 E-Mail Alphanumeric]), DATALENGTH([33 E-Mail Alphanumeric]) - charindex('~', [33 E-Mail Alphanumeric])) else '' end, '~', '') as work_email
	from f01
	where 1=1
	and [16 Site Xref] is null 
	and [1 Name Alphanumeric] not like 'xx%'
	union all
	select *
	 ,replace(case when charindex('~', [33 E-Mail Alphanumeric]) >= 10 then substring([33 E-Mail Alphanumeric], 1, charindex('~', [33 E-Mail Alphanumeric])) else [33 E-Mail Alphanumeric] end, '~', '') as primary_email
     ,replace(case when charindex('~', [33 E-Mail Alphanumeric]) >= 10 then substring([33 E-Mail Alphanumeric], charindex('~', [33 E-Mail Alphanumeric]), DATALENGTH([33 E-Mail Alphanumeric]) - charindex('~', [33 E-Mail Alphanumeric])) else '' end, '~', '') as work_email
	from f01 a
	where 1=1
	and [16 Site Xref] is NOT null 
	and exists(select 1 from f03 as x where x.[20 Contact Xref] = a.UniqueID)
	--and exists (select 1 from [All_Applications_180831] as x where x.[Cand id] = F01.[4 RefNumber Numeric])
	and [1 Name Alphanumeric] not like 'xx%'
) as a
left join yyy on yyy.[4 Candidate Xref] = a.UniqueID
where [28 Created Date] <>'00/01/1901'
and 
(
  convert(date, [28 Created Date], 103) >= '2013-01-01'
  or
   (
		convert(date, [28 Created Date], 103) < '2013-01-01'
		and (
		     penultimate_action in
				(
				'Web Arrange Interview',
				'Cons Interview Booked',
				'Cons Interview Complete',
				'Client 1st I/V Booked',
				'Client 1st I/V Complete',
				'Client 2nd I/V Booked',
				'Client 2nd I/V Complete',
				'Client 3rd I/V Booked',
				'Client 3rd I/V Complete',
				'Client 4th I/V Booked',
				'Client 4th I/V Complete',
				'Verification'
				)
			or [41 Last Conta Date] >= '2013-01-01' 
			or last_action is not null
			) 
   )
)
	

) as a
LEFT JOIN(SELECT * FROM CODES WHERE Codegroup = 4) as c on c.Code = a.[3 Status Codegroup   4]
LEFT JOIN i on i.UniqueID = a.UniqueID
LEFT JOIN cc on cc.UniqueID = a.UniqueID
LEFT JOIN F39 on F39.UniqueID = a.[203 Suburb Xref]
LEFT JOIN skill on skill.UniqueID = a.UniqueID
LEFT JOIN (SELECT * FROM jobhist WHERE rnk = 1) as jh1 on jh1.[1 Candidate Xref] = a.UniqueID
LEFT JOIN (SELECT * FROM jobhist WHERE rnk = 2) as jh2 on jh2.[1 Candidate Xref] = a.UniqueID
LEFT JOIN (SELECT * FROM jobhist WHERE rnk = 3) as jh3 on jh3.[1 Candidate Xref] = a.UniqueID
OUTER APPLY
(
   select [1 Candidate Xref]
      ,  STUFF((select char(10) + cast(x.id as varchar(30)) + ' - ' + x.company + ' - ' + x.job + ' - ' + convert(varchar(20), x.startdate, 103) + ' - ' 
	  + convert(varchar(20), x.enddate,103)
	from jobhist as x where x.[1 Candidate Xref] = jobhist.[1 Candidate Xref] and x.rnk > 3 for xml path('')), 1,2,'') as FN
	FROM jobhist 
	WHERE jobhist.[1 Candidate Xref] = a.UniqueID
	GROUP BY [1 Candidate Xref]
) as jhs
LEFT JOIN cd on cd.UniqueID = a.UniqueID
left join(select * from px where px.ItemNumber = 3) as px3 on px3.uniqueid = a.uniqueid
left join(select * from px where px.ItemNumber = 1) as px1 on px1.uniqueid = a.uniqueid
left join(select * from px where px.ItemNumber = 2) as px2 on px2.uniqueid = a.uniqueid
left join(select * from px where px.ItemNumber = 4) as px4 on px4.uniqueid = a.uniqueid

