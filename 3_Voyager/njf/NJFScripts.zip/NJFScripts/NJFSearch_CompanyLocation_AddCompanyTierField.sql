ALTER TABLE company_location
ADD COLUMN company_tier_id int;