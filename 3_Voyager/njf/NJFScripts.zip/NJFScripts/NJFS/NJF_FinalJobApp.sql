select 
applicationpositionExternalId 'application-positionExternalId'
, applicationcandidateExternalId 'application-candidateExternalId'
, applicationStage 'application-Stage'
from importJobApp